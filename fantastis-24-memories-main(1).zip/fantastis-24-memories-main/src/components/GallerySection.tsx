import { Card } from "@/components/ui/card";
import bukaBersama from "@/assets/gallery-1-buka-bersama.jpeg";
import cssCompetition from "@/assets/gallery-2-css-competition.jpeg";
import eventTanamBakau from "@/assets/gallery-3-event-tanam-bakau.jpeg";
import fotoBersama from "@/assets/gallery-4-foto-bersama.jpeg";
import ktpt from "@/assets/gallery-5-ktpt.jpeg";
import kumpulPerdana from "@/assets/gallery-6-kumpul-perdana.jpeg";
import nontonBersama from "@/assets/gallery-7-nonton-bersama.jpeg";
import panitiaFarewell from "@/assets/gallery-8-panitia-farewell.jpeg";
import sportdayPerdana from "@/assets/gallery-9-sportday-perdana.jpeg";
import ziarahWalisongo from "@/assets/gallery-10-ziarah-walisongo.jpeg";
import sunanAmpel from "@/assets/gallery-11-sunan-ampel.jpeg";
import hasarnas from "@/assets/gallery-12-hasarnas.jpeg";

interface GalleryItem {
  id: number;
  image: string;
  caption: string;
}

const galleryItems: GalleryItem[] = [
  { id: 1, image: bukaBersama, caption: "Buka Bersama" },
  { id: 2, image: cssCompetition, caption: "CSS-Competition" },
  { id: 3, image: eventTanamBakau, caption: "Event Tanam Bakau" },
  { id: 4, image: fotoBersama, caption: "Foto Studio Bersama" },
  { id: 5, image: ktpt, caption: "KTPT" },
  { id: 6, image: kumpulPerdana, caption: "Kumpul Perdana" },
  { id: 7, image: nontonBersama, caption: "Nonton Bersama" },
  { id: 8, image: panitiaFarewell, caption: "Panitia Farewell Party" },
  { id: 9, image: sportdayPerdana, caption: "Sport Day Perdana" },
  { id: 10, image: ziarahWalisongo, caption: "Rihlah Walisongo" },
  { id: 11, image: sunanAmpel, caption: "Sunan Ampel Visit" },
  { id: 12, image: hasarnas, caption: "HASARNAS 2024" },
];

const GallerySection = () => {
  return (
    <section id="gallery" className="min-h-screen py-20 bg-gradient-to-br from-background via-accent to-background">
      <div className="container mx-auto px-4">
        <h2 className="text-5xl md:text-6xl font-bold text-center text-primary mb-4 animate-fade-in">
          Galeri Kegiatan
        </h2>
        <p className="text-center text-muted-foreground mb-16 text-lg">
          Momen kebersamaan yang tak terlupakan
        </p>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {galleryItems.map((item, idx) => (
            <Card
              key={item.id}
              className="group relative overflow-hidden rounded-2xl border-0 shadow-card hover:shadow-elevated transition-smooth hover:-translate-y-2 cursor-pointer aspect-square"
              style={{ animationDelay: `${idx * 50}ms` }}
            >
              <img
                src={item.image}
                alt={item.caption}
                className="w-full h-full object-cover group-hover:scale-110 transition-slow"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/90 via-primary/50 to-transparent opacity-0 group-hover:opacity-100 transition-smooth flex items-end p-4">
                <p className="text-white font-medium text-sm md:text-base transform translate-y-4 group-hover:translate-y-0 transition-smooth">
                  {item.caption}
                </p>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default GallerySection;
