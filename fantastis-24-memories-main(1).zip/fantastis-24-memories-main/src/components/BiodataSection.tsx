import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import memberRayhan from "@/assets/member-1-rayhan.png";
import memberAiman from "@/assets/member-2-aiman.png";
import memberRendi from "@/assets/member-3-rendi.png";
import memberAhmad from "@/assets/member-4-ahmad.png";
import memberAzza from "@/assets/member-5-azza.png";
import memberTakhta from "@/assets/member-6-takhta.png";
import memberWaliana from "@/assets/member-7-waliana.jpeg";
import memberFadhillah from "@/assets/member-8-fadhillah.png";
import memberAfif from "@/assets/member-9-afif.png";
import memberChowahir from "@/assets/member-10-chowahir.png";
import memberIkhlasul from "@/assets/member-11-ikhlasul.png";
import memberTamam from "@/assets/member-12-tamam.png";
import memberMutira from "@/assets/member-13-mutira.png";
import memberShabrina from "@/assets/member-14-shabrina.png";
import memberFaisa from "@/assets/member-15-faisa.png";
import memberMiftachul from "@/assets/member-16-miftachul.png";

interface Member {
  id: number;
  name: string;
  university: string;
  region: string;
  photo: string;
}

const members: Member[] = [
  { id: 1, name: "Muhammad Rayhan Lubis", university: "Manajemen Zakat dan Wakaf", region: "Jakarta", photo: memberRayhan },
  { id: 2, name: "Muhammad Aiman", university: "Manajemen Zakat dan Wakaf", region: "Aceh", photo: memberAiman },
  { id: 3, name: "Rendi Pratama", university: "Manajemen Zakat dan Wakaf", region: "Riau", photo: memberRendi },
  { id: 4, name: "Ahmad Dhani Ihsan", university: "Manajemen Zakat dan Wakaf", region: "Blora", photo: memberAhmad },
  { id: 5, name: "Azza Maulani Khoirunnisa", university: "Manajemen Zakat dan Wakaf", region: "Bekasi", photo: memberAzza },
  { id: 6, name: "Takhta Alfina", university: "Manajemen Zakat dan Wakaf", region: "Sidoarjo", photo: memberTakhta },
  { id: 7, name: "Waliana Dwi Lisnaya", university: "Manajemen Zakat dan Wakaf", region: "Kediri", photo: memberWaliana },
  { id: 8, name: "Fadhillah Fitria Ummah", university: "Manajemen Zakat dan Wakaf", region: "Pontianak", photo: memberFadhillah },
  { id: 9, name: "Afif Abdussami'", university: "Pengembangan Masyarakat Islam", region: "Blitar", photo: memberAfif },
  { id: 10, name: "M.Chowahir Zaada", university: "Pengembangan Masyarakat Islam", region: "Bojonegoro", photo: memberChowahir },
  { id: 11, name: "Muhammad Ikhlasul Arifin", university: "Pengembangan Masyarakat Islam", region: "Sidoarjo", photo: memberIkhlasul },
  { id: 12, name: "Muhammad Tamam Aufal Haq", university: "Pengembangan Masyarakat Islam", region: "Lamongan", photo: memberTamam },
  { id: 13, name: "Mutira Azuraa Ramadhani", university: "Pengembangan Masyarakat Islam", region: "Kulon Progo", photo: memberMutira },
  { id: 14, name: "Shabrina Maulany", university: "Pengembangan Masyarakat Islam", region: "Jambi", photo: memberShabrina },
  { id: 15, name: "Faisa Ainun Nisa", university: "Pengembangan Masyarakat Islam", region: "Pati", photo: memberFaisa },
  { id: 16, name: "Miftachul Ilma Dwi Putri Nabila", university: "Pengembangan Masyarakat Islam", region: "Sidoarjo", photo: memberMiftachul },
];

const BiodataSection = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const itemsPerPage = 4;
  const maxIndex = Math.ceil(members.length / itemsPerPage) - 1;

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev >= maxIndex ? 0 : prev + 1));
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev <= 0 ? maxIndex : prev - 1));
  };

  const visibleMembers = members.slice(
    currentIndex * itemsPerPage,
    (currentIndex + 1) * itemsPerPage
  );

  return (
    <section id="biodata" className="min-h-screen py-20 bg-accent">
      <div className="container mx-auto px-4">
        <h2 className="text-5xl md:text-6xl font-bold text-center text-primary mb-4 animate-fade-in">
          Kenal Lebih Dekat
        </h2>
        <p className="text-center text-muted-foreground mb-16 text-lg">
          Kenali anggota Fantastis 24 yang luar biasa
        </p>

        <div className="relative">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {visibleMembers.map((member, idx) => (
              <Card 
                key={member.id} 
                className="gradient-card border-0 shadow-card hover:shadow-elevated transition-smooth hover:-translate-y-2 group overflow-hidden"
                style={{ animationDelay: `${idx * 100}ms` }}
              >
                <CardContent className="p-6 text-center">
                  <div className="relative w-32 h-32 mx-auto mb-4 rounded-full overflow-hidden shadow-soft group-hover:scale-110 transition-smooth">
                    <img
                      src={member.photo}
                      alt={member.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-2 font-playfair">
                    {member.name}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-1">
                    {member.university}
                  </p>
                  <p className="text-sm text-primary font-medium">
                    {member.region}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="flex justify-center items-center gap-4">
            <Button
              variant="outline"
              size="icon"
              onClick={prevSlide}
              className="rounded-full w-12 h-12 shadow-soft hover:shadow-card transition-smooth hover:scale-110 border-primary/20"
            >
              <ChevronLeft className="h-6 w-6 text-primary" />
            </Button>

            <div className="flex gap-2">
              {Array.from({ length: maxIndex + 1 }).map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentIndex(idx)}
                  className={`w-2 h-2 rounded-full transition-smooth ${
                    idx === currentIndex 
                      ? 'bg-primary w-8' 
                      : 'bg-primary/30 hover:bg-primary/50'
                  }`}
                  aria-label={`Go to slide ${idx + 1}`}
                />
              ))}
            </div>

            <Button
              variant="outline"
              size="icon"
              onClick={nextSlide}
              className="rounded-full w-12 h-12 shadow-soft hover:shadow-card transition-smooth hover:scale-110 border-primary/20"
            >
              <ChevronRight className="h-6 w-6 text-primary" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BiodataSection;
