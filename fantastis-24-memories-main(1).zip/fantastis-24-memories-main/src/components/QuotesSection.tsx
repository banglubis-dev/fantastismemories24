import { Quote } from "lucide-react";

const QuotesSection = () => {
  return (
    <section id="quotes" className="min-h-screen flex items-center justify-center bg-gradient-to-br from-secondary-light via-secondary to-secondary-light relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,rgba(255,255,255,0.3),transparent_60%)]" />
      
      <div className="container mx-auto px-4 text-center relative z-10 max-w-4xl animate-fade-in">
        <Quote className="w-16 h-16 text-secondary-foreground/30 mx-auto mb-8" />
        
        <blockquote className="space-y-6">
          <p className="text-3xl md:text-5xl font-playfair font-semibold text-secondary-foreground leading-relaxed italic">
            "Kebersamaan itu seperti permulaan, kemudian menjaga kebersamaan merupakan kemajuan dan bekerja bersama merupakan keberhasilan."
          </p>
          <footer className="text-xl md:text-2xl text-secondary-foreground/80 font-medium">
            — Henry Ford
          </footer>
        </blockquote>

        <div className="mt-12 flex justify-center gap-3">
          <div className="w-16 h-1 bg-secondary-foreground/30 rounded-full" />
          <div className="w-8 h-1 bg-secondary-foreground/20 rounded-full" />
          <div className="w-4 h-1 bg-secondary-foreground/10 rounded-full" />
        </div>
      </div>
    </section>
  );
};

export default QuotesSection;
