import { ArrowDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroBg from "@/assets/hero-bg.jpeg";

const HeroSection = () => {
  const scrollToBiodata = () => {
    const biodataSection = document.getElementById('biodata');
    biodataSection?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroBg})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-primary/80 via-primary/60 to-background/95" />
      
      <div className="container mx-auto px-4 text-center relative z-10 animate-fade-in">
        <h1 className="text-6xl md:text-8xl font-bold text-primary mb-6 tracking-tight">
          Fantastis 24
        </h1>
        
        <p className="text-lg md:text-xl text-foreground/80 max-w-3xl mx-auto mb-12 leading-relaxed">
          Mahasiswa-Mahasiswi Awardee PBSB Kemenag dan LPDP<br />
          serta Anggota Aktif CSSMoRA UINSA Tahun 2024
        </p>

        <Button
          size="lg"
          onClick={scrollToBiodata}
          className="bg-primary hover:bg-primary-dark text-primary-foreground px-8 py-6 text-lg rounded-full shadow-elevated transition-smooth hover:scale-105 group"
        >
          Tak Kenal Maka Tak Sayang
          <ArrowDown className="ml-2 h-5 w-5 group-hover:translate-y-1 transition-smooth" />
        </Button>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <ArrowDown className="h-6 w-6 text-primary/50" />
      </div>
    </section>
  );
};

export default HeroSection;
