import { Instagram, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";

const AboutSection = () => {
  return (
    <section id="about" className="min-h-screen flex flex-col items-center justify-center bg-background py-20">
      <div className="container mx-auto px-4 text-center max-w-2xl animate-fade-in">
        <h2 className="text-5xl md:text-6xl font-bold text-primary mb-8">
          Hubungi Kami
        </h2>
        
        <p className="text-lg text-muted-foreground mb-8">
          Ikuti perjalanan kami dan jangan lewatkan update terbaru dari Fantastis 24
        </p>

        <a
          href="https://instagram.com/fantastis24_"
          target="_blank"
          rel="noopener noreferrer"
        >
          <Button
            size="lg"
            className="bg-gradient-accent hover:opacity-90 text-white px-8 py-6 text-lg rounded-full shadow-elevated transition-smooth hover:scale-105 group"
          >
            <Instagram className="mr-2 h-6 w-6 group-hover:rotate-12 transition-smooth" />
            @fantastis24_
          </Button>
        </a>

        <div className="mt-20 pt-12 border-t border-border">
          <p className="text-muted-foreground flex items-center justify-center gap-2">
            © 2024 Fantastis 24 — Created with
            <Heart className="h-4 w-4 text-destructive fill-destructive animate-pulse" />
            by Our Angkatan
          </p>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
