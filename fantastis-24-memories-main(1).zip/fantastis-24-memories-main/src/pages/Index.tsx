import HeroSection from "@/components/HeroSection";
import BiodataSection from "@/components/BiodataSection";
import GallerySection from "@/components/GallerySection";
import QuotesSection from "@/components/QuotesSection";
import AboutSection from "@/components/AboutSection";

const Index = () => {
  return (
    <main className="overflow-x-hidden">
      <HeroSection />
      <BiodataSection />
      <GallerySection />
      <QuotesSection />
      <AboutSection />
    </main>
  );
};

export default Index;
